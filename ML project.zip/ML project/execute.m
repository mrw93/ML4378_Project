%% Facebook Ego Network Dataset
% We will just reload the preprocessed data from
% <https://blogs.mathworks.com/images/loren/2016/facebook.mat>

clearvars                                           % clear workspace
load facebook                                       % load mat file
who

%% Visualize Combined Ego Networks

comb = vertcat(edges{:});                           % combine edges
comb = sort(comb, 2);                               % sort edge order
comb = unique(comb,'rows');                         % remove duplicates
comb = comb + 1;                                    % convert to 1-indexing
combG = graph(comb(:,1),comb(:,2));                 % create undirected graph
notConnected = find(degree(combG) == 0);            % find unconnected nodes
combG = rmnode(combG, notConnected);                % remove them

edgeC = [.7 .7 .7];                                 % gray color

figure
H = plot(combG,'MarkerSize',1,'EdgeColor',edgeC, ...% plot graph
    'EdgeAlpha',0.3); 
title('Combined Ego Networks')                      % add title
text(17,13,sprintf('Total %d nodes', ...            % add node metric
    numnodes(combG)))     
text(17,12,sprintf('Total %d edges', ...            % add edge metric
    numedges(combG)))
text(17,11,'Ego nodes shown in red')                % add edge metric
  
egos = intersect(egoids + 1, unique(comb));         % find egos in the graph
highlight(H,egos,'NodeColor','r','MarkerSize',3)    % highlight them in red 

%% Visualize a Single Ego Network - Degree Centrality
% the ego node is not included in this analysis as because by nature the
% ego node will always be the top node, so there is no point including it.

idx = 2;                                            % pick an ego node
egonode = num2str(egoids(idx));                     % ego node name as string
G = graphs{idx};                                    % get its graph
deg = degree(G);                                    % get node degrees
notConnected = find(deg < 2);                       % weakly connected nodes
deg(notConnected) = [];                             % drop them from deg           
G = rmnode(G, notConnected);                        % drop them from graph
[~, ranking] = sort(deg,'descend');                 % get ranking by degree
top3 = G.Nodes.Name(ranking(1:3));                  % get top 3 node names

figure
colormap cool                                       % set color map
H = plot(G,'MarkerSize',log(deg), ...               % node size in log scale
    'NodeCData',deg,...                             % node color by degree
    'EdgeColor',edgeC,'EdgeAlpha',0.3);
labelnode(H,top3,{'#1','#2','#3'});                 % label top 3 nodes
title({sprintf('Ego Network of Node %d', ...        % add title
    egoids(idx)); 'colored by Degree Centrality'})
text(-1,-3,['top 3 nodes: ',strjoin(top3)])         % annotate                                    
H = colorbar;                                       % add colorbar
ylabel(H, 'degrees')                                % add metric as ylabel

%% Shortest Paths 
 
[path, d] = shortestpath(G,top3{1},'483');          % get shortest path 
 
figure
H = plot(G,'MarkerSize',1,'EdgeColor',edgeC);       % plot graph
highlight(H,path,'NodeColor','r', ...               % highlight path
    'MarkerSize',3,'EdgeColor','r','LineWidth',2)
labelnode(H,path, [{'Top node'} path(2:end)])       % label nodes
title('Shortest Path between Top Node and Node 483')% add title
text(-1,-3,sprintf('Distance: %d hops',d))          % annotate
 
%% Closeness Centrality
 
load dist

closeness = 1./sum(dist);                           % compute closeness
[~, ranking] = sort(closeness, 'descend');          % get ranking by closeness
top3 = G.Nodes.Name(ranking(1:3));                  % get top 3 node names              
 
figure
colormap cool                                       % set color map
H = plot(G,'MarkerSize',closeness*10000, ...        % node size by closeness
    'NodeCData',closeness,...                       % node color by closeness
    'EdgeColor',edgeC,'EdgeAlpha',0.3);
labelnode(H,top3,{'#1','#2','#3'});                 % label top 3 nodes
title({sprintf('Ego Network of Node %d', ...        % add title
    egoids(idx)); 'colored by Closeness Centrality'})
text(-1,-3,['top 3 nodes: ',strjoin(top3)])         % annotate                                    
H = colorbar;                                       % add colorbar
ylabel(H, 'closeness')                              % add metric as ylabel
